# Screaming Eagle

### *A Legend of Protective Fire*

A limited edition fable by [SpiceQuest](https://spicequestlabs.com), presented as an interactive flipbook.

## Read it

**→ [Open the flipbook](https://USERNAME.github.io/REPO-NAME/)**

*(Replace `USERNAME` and `REPO-NAME` after you set up GitHub Pages — see below.)*

## About

The Screaming Eagle is the sequel to *Crying Lion*, the inaugural SpiceQuest fable. Where the first tale was about a King who needed fire to feel joy, this one is about a Guardian who uses fire to protect what is small.

**The pepper:** 875,000 SHU. Fierce, beautiful, and feared by the large.

## How to use

- **← →** turn the page
- **Space** play/pause autoplay
- **Click** the left or right edges to turn
- **Swipe** on mobile

## Credits

Story and art: SpiceQuest
Flipbook engine: a single self-contained `index.html` — no dependencies, no tracking, no build step.

---

*The early bird did not get the worm. The early bird saved it.*
